from Query import get_data

print get_data('ZJTMI','2016.5.3.0.0','2016.6.20.0.0')

